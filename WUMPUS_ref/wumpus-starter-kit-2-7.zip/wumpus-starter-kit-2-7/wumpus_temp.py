import wumpus_main

# normal play
debug = 0
# fixed map for debugging
#debug = 1 
# fixed, visible map for debugging
#debug = 2

wumpus_main.main(debug)
